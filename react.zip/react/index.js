// ReactDOM.render(<h1>this is shruu</h1>, document.getElementById('root'))
ReactDOM.render(
<p>A day in my life
<ul>
    <li>snack</li>
    <li>study</li>
    <li>binge</li>
    <li>sleep</li>
</ul></p>, document.getElementById('root'))